window.addEventListener("DOMContentLoaded", async () => {
  const datalist = document.getElementById("remedios-lista");

  try {
    const response = await fetch("/api/remedios/nomes");
    const nomes = await response.json();

    nomes.forEach((nome) => {
      const option = document.createElement("option");
      option.value = nome;
      datalist.appendChild(option);
    });
  } catch (err) {
    console.error("Erro ao carregar lista de remédios:", err);
  }
});

// CPF: formatação automática
document.getElementById("cpf").addEventListener("input", function () {
  let cpf = this.value.replace(/\D/g, "");
  if (cpf.length > 11) cpf = cpf.slice(0, 11);

  if (cpf.length > 9) {
    this.value = cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4");
  } else if (cpf.length > 6) {
    this.value = cpf.replace(/(\d{3})(\d{3})(\d+)/, "$1.$2.$3");
  } else if (cpf.length > 3) {
    this.value = cpf.replace(/(\d{3})(\d+)/, "$1.$2");
  } else {
    this.value = cpf;
  }
});

// Buscar cliente automaticamente
document.getElementById("cpf").addEventListener("blur", async function () {
  const cpfNumeros = this.value.replace(/\D/g, "");

  if (cpfNumeros.length === 11) {
    try {
      const response = await fetch(`/api/clientes?cpf=${cpfNumeros}`);
      const cliente = await response.json();

      if (cliente && cliente.nome) {
        document.getElementById("nome_cliente").value = cliente.nome;
        this.dataset.clienteId = cliente.id;
      } else {
        document.getElementById("nome_cliente").value = "";
        delete this.dataset.clienteId;
        alert("Cliente não encontrado.");
      }
    } catch (err) {
      console.error("Erro ao buscar cliente:", err.message);
      alert("Erro ao buscar cliente.");
    }
  }
});

// Formatar data enquanto digita (dd/mm/aaaa)
function formatarData(input) {
  let v = input.value.replace(/\D/g, "");
  if (v.length >= 3 && v.length <= 4) v = v.replace(/(\d{2})(\d{1,2})/, "$1/$2");
  else if (v.length > 4) v = v.replace(/(\d{2})(\d{2})(\d{1,4})/, "$1/$2/$3");
  input.value = v;
}

// Enviar dados da receita
document.getElementById("form-remedio").addEventListener("submit", async function (e) {
  e.preventDefault();

  const cpfInput = document.getElementById("cpf");
  const clienteId = cpfInput.dataset.clienteId;
  const nomeRemedio = document.getElementById("nome_remedio").value.trim();
  let validade = document.getElementById("validade_receita").value;
  const dosagem = document.getElementById("dosagem").value.trim(); // ⬅️ Agora está no lugar certo

  if (!clienteId || !nomeRemedio || !validade || !dosagem) {
    alert("Por favor, preencha todos os campos.");
    return;
  }

  if (validade.includes("/")) {
    const partes = validade.split("/");
    validade = `${partes[2]}-${partes[1]}-${partes[0]}`;
  }

  const dados = {
    cpf: cpfInput.value,
    nome_remedio: nomeRemedio,
    validade_receita: validade,
    dosagem: dosagem
  };

  try {
    const response = await fetch("/api/remedios", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(dados),
    });

    const result = await response.json();
    if (response.ok) {
      Swal.fire("Sucesso", "Receita cadastrada com sucesso!", "success");
      this.reset();
      document.getElementById("nome_remedio").value = "";
      document.getElementById("validade_receita").value = "";
      document.getElementById("dosagem").value = "";
    } else {
      Swal.fire("Erro", result.error || "Erro ao cadastrar remédio.", "error");
    }
  } catch (err) {
    console.error("Erro ao enviar dados:", err.message);
    alert("Erro ao cadastrar remédio.");
  }
});

// Cadastrar nova receita para mesmo cliente
function voltarParaReceita() {
  document.getElementById("nome_remedio").value = "";
  document.getElementById("validade_receita").value = "";
  document.getElementById("dosagem").value = "";
  document.getElementById("nome_remedio").focus();
}
