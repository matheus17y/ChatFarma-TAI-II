document.addEventListener("DOMContentLoaded", async () => {
  try {
    const response = await fetch("/api/dashboard");
    const data = await response.json();

    if (!response.ok) {
      Swal.fire({
        icon: 'error',
        title: 'Erro!',
        text: data.error || 'Erro ao carregar dashboard.',
        confirmButtonColor: '#d33'
      });
      return;
    }

    document.getElementById("total-clientes").textContent = data.totalClientes;
    document.getElementById("total-remedios").textContent = data.totalRemedios;

    // Vencendo em até 7 dias
    const vencendo = document.getElementById("tabela-vencendo");
    if (Array.isArray(data.vencendoNosProximosDias) && data.vencendoNosProximosDias.length > 0) {
      data.vencendoNosProximosDias.forEach(item => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>${item.cliente}</td>
          <td>${item.nome_remedio}</td>
          <td>${item.validade_receita}</td>
        `;
        vencendo.appendChild(tr);
      });
    } else {
      vencendo.innerHTML = `<tr><td colspan="3">Nenhum remédio vencendo nos próximos 7 dias.</td></tr>`;
    }

    // Vencendo após 7 dias
    const naoVencendo = document.getElementById("tabela-nao-vencendo");
    if (Array.isArray(data.vencendoApos7Dias) && data.vencendoApos7Dias.length > 0) {
      data.vencendoApos7Dias.forEach(item => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>${item.cliente}</td>
          <td>${item.nome_remedio}</td>
          <td>${item.validade_receita}</td>
          <td>${item.dias_restantes}</td>
        `;
        naoVencendo.appendChild(tr);
      });
    } else {
      naoVencendo.innerHTML = `<tr><td colspan="4">Nenhum remédio com vencimento distante.</td></tr>`;
    }

  } catch (err) {
    Swal.fire({
      icon: 'error',
      title: 'Erro!',
      text: err.message,
      confirmButtonColor: '#d33'
    });
  }
});

function excluirReceita(id) {
  Swal.fire({
    title: 'Tem certeza?',
    text: 'Deseja realmente excluir esta receita?',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Sim, excluir',
    cancelButtonText: 'Cancelar'
  }).then((result) => {
    if (result.isConfirmed) {
      fetch(`/api/remedios/${id}`, {
        method: "DELETE",
      })
        .then(res => res.json())
        .then(data => {
          Swal.fire("Feito!", data.message, "success").then(() => location.reload());
        })
        .catch(err => {
          console.error("Erro:", err);
          Swal.fire("Erro", "Erro ao excluir receita.", "error");
        });
    }
  });
}
