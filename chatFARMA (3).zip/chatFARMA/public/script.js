
document.getElementById("form-cadastro").addEventListener("submit", async function (e) {
  e.preventDefault();

  const nome = document.getElementById("nome").value.trim();
  let data_nasc = document.getElementById("data_nasc").value.trim();
  const sexo = document.getElementById("sexo").value;
  let telefone = document.getElementById("telefone").value.trim();
  let celular = document.getElementById("celular").value.trim();
  let rg = document.getElementById("rg").value.trim();
  let cpf = document.getElementById("cpf").value.trim();
  const endereco = document.getElementById("endereco").value.trim();
  const email = document.getElementById("email").value.trim();

  // 🔄 Limpa pontuação
  cpf = cpf.replace(/\D/g, "");
  rg = rg.replace(/\D/g, "");
  celular = celular.replace(/\D/g, "");
  telefone = telefone.replace(/\D/g, "");

  // ✅ Envia como dd/mm/aaaa
  const atualizar = false;

  try {
    const response = await fetch("/api/clientes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        nome,
        telefone,
        celular,
        cpf,
        data_nasc,
        sexo,
        rg,
        endereco,
        email,
        atualizar
      }),
    });

    const data = await response.json();

    if (response.ok) {
      Swal.fire("Sucesso", data.message, "success");
      document.getElementById("form-cadastro").reset();
    } else {
      Swal.fire("Erro", data.error || "Erro ao cadastrar.", "error");
    }
  } catch (error) {
    console.error("Erro na requisição:", error);
    Swal.fire("Erro", "Erro ao enviar dados para o servidor.", "error");
  }
});

//  Formatação da data ao digitar
function formatarData(input) {
  let v = input.value.replace(/\D/g, "");
  if (v.length >= 3 && v.length <= 4) v = v.replace(/(\d{2})(\d{1,2})/, "$1/$2");
  else if (v.length > 4) v = v.replace(/(\d{2})(\d{2})(\d{1,4})/, "$1/$2/$3");
  input.value = v;
}

function formatarCPF(input) {
  let v = input.value.replace(/\D/g, "");
  v = v.replace(/(\d{3})(\d)/, "$1.$2");
  v = v.replace(/(\d{3})(\d)/, "$1.$2");
  v = v.replace(/(\d{3})(\d{1,2})$/, "$1-$2");
  input.value = v;
}

function formatarCelular(input) {
  let valor = input.value.replace(/\D/g, "");

  // Remove qualquer duplicidade do +55
  if (valor.startsWith("55")) {
    valor = valor.substring(2);
  }

  // Limita a 11 dígitos (2 do DDD + 9 do número)
  valor = valor.substring(0, 11);

  // Monta a string formatada
  if (valor.length <= 2) {
    input.value = `+55 (${valor}`;
  } else if (valor.length <= 6) {
    input.value = `+55 (${valor.slice(0, 2)}) ${valor.slice(2)}`;
  } else {
    input.value = `+55 (${valor.slice(0, 2)}) ${valor.slice(2, 7)}-${valor.slice(7)}`;
  }
}

function inicializarCelular(input) {
  if (!input.value.startsWith("+55")) {
    input.value = "+55 (";
  }
}
