document.getElementById("form-login").addEventListener("submit", async function (event) {
  event.preventDefault();

  const usuario = document.getElementById("usuario").value;
  const senha = document.getElementById("senha").value;

  try {
    const response = await fetch("/api/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ usuario, senha })
    });

    const result = await response.json();

    if (response.ok) {
      Swal.fire({
        icon: 'success',
        title: 'Bem-vindo!',
        text: result.message,
        confirmButtonColor: '#00BFA5'
      }).then(() => {
        window.location.href = "home.html"; // Redireciona para o cadastro
      });
    } else {
      Swal.fire({
        icon: 'error',
        title: 'Erro!',
        text: result.error || 'Usuário ou senha inválidos!',
        confirmButtonColor: '#d33'
      });
    }

  } catch (error) {
    Swal.fire({
      icon: 'error',
      title: 'Erro na requisição!',
      text: error.message,
      confirmButtonColor: '#d33'
    });
  }
});
