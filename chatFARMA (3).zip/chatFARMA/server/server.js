require("dotenv").config();

// server.js
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const path = require("path");
const db = require("./database");
const { enviarMensagemWhatsApp } = require("./twilioService");

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());

// Rota inicial
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "../public/login.html"));
});

app.use(express.static("public"));

// Login
app.post("/api/login", (req, res) => {
  const { usuario, senha } = req.body;
  db.get(
    "SELECT * FROM usuarios WHERE usuario = ? AND senha = ?",
    [usuario, senha],
    (err, row) => {
      if (err) return res.status(500).json({ error: "Erro ao verificar login." });
      if (row) return res.status(200).json({ message: "Login bem-sucedido!" });
      return res.status(401).json({ error: "Usuário ou senha incorretos." });
    }
  );
});

// Cadastro de clientes
app.post("/api/clientes", (req, res) => {
  let { nome, telefone, celular, cpf, data_nasc, email, sexo, rg, endereco, atualizar } = req.body;
  cpf = cpf.replace(/\D/g, "");
  if (data_nasc?.includes("/")) {
    const partes = data_nasc.split("/");
    data_nasc = `${partes[2]}-${partes[1]}-${partes[0]}`;
  }
  db.get("SELECT * FROM clientes WHERE cpf = ?", [cpf], (err, row) => {
    if (err) return res.status(500).json({ error: "Erro ao buscar cliente." });
    if (row) {
      if (atualizar) {
        db.run("UPDATE clientes SET telefone = ?, email = ? WHERE cpf = ?", [telefone, email, cpf], (err2) => {
          if (err2) return res.status(500).json({ error: "Erro ao atualizar cliente." });
          return res.status(200).json({ message: "Telefone e Email atualizados com sucesso!" });
        });
      } else {
        return res.status(409).json({ error: "Cliente já cadastrado." });
      }
    } else {
      const sql = `
        INSERT INTO clientes (nome, telefone, celular, cpf, data_nasc, sexo, rg, endereco, email)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;
      db.run(sql, [nome, telefone, celular, cpf, data_nasc, sexo, rg, endereco, email], (err3) => {
        if (err3) return res.status(500).json({ error: "Erro ao cadastrar cliente." });
        res.status(201).json({ message: "Cliente cadastrado com sucesso!" });
      });
    }
  });
});

app.get("/api/clientes", (req, res) => {
  const { cpf } = req.query;
  if (!cpf) {
    db.all("SELECT * FROM clientes", [], (err, rows) => {
      if (err) return res.status(500).json({ error: "Erro ao buscar clientes." });
      res.json(rows);
    });
  } else {
    const cpfLimpo = cpf.replace(/\D/g, "");
    db.get("SELECT * FROM clientes WHERE cpf = ?", [cpfLimpo], (err, row) => {
      if (err) return res.status(500).json({ error: "Erro ao buscar cliente." });
      if (row) return res.json(row);
      res.status(404).json({ error: "Cliente não encontrado." });
    });
  }
});

// Cadastro de remédios
// Cadastro de remédios
app.post("/api/remedios", (req, res) => {
  let { cpf, nome_remedio, validade_receita, dosagem } = req.body;
  if (!cpf || !nome_remedio || !validade_receita || !dosagem) {
    return res.status(400).json({ error: "Todos os campos são obrigatórios." });
  }

  cpf = cpf.replace(/\D/g, "");
  if (validade_receita.includes("/")) {
    const partes = validade_receita.split("/");
    validade_receita = `${partes[2]}-${partes[1]}-${partes[0]}`;
  }

  db.get("SELECT * FROM clientes WHERE cpf = ?", [cpf], (err, cliente) => {
    if (err || !cliente) return res.status(400).json({ error: "Cliente não encontrado." });

    db.run(
      `INSERT INTO remedios (cliente_id, nome_remedio, validade_receita, dosagem) VALUES (?, ?, ?, ?)`,
      [cliente.id, nome_remedio, validade_receita, dosagem],
      async (err2) => {
        if (err2) return res.status(500).json({ error: "Erro ao cadastrar remédio." });

        let numero = cliente.celular.replace(/\D/g, '');
        numero = `+${numero}`;

        db.get("SELECT nome FROM farmacia WHERE id = 1", async (errF, farmacia) => {
          if (errF || !farmacia) farmacia = { nome: "sua farmácia" };

          const mensagem = `Olá ${cliente.nome}! Sua receita para ${nome_remedio} foi cadastrada com sucesso pela ${farmacia.nome}.`;

          try {
            await enviarMensagemWhatsApp(numero, mensagem);

            const dataEnvio = new Date().toISOString().split("T")[0];
            db.run(
              `INSERT INTO mensagens (cliente_id, tipo, data_envio) VALUES (?, ?, ?)`,
              [cliente.id, "cadastro_receita", dataEnvio],
              (err3) => {
                if (err3) console.error("Erro ao registrar envio:", err3.message);
              }
            );

            res.status(201).json({ message: "Receita cadastrada e mensagem enviada!" });
          } catch (twilioErr) {
            console.error("Erro ao enviar WhatsApp:", twilioErr.message);
            res.status(201).json({
              message: "Receita cadastrada, mas falha ao enviar WhatsApp."
            });
          }
        });
      }
    );
  });
});

// Dashboard
app.get("/api/dashboard", (req, res) => {
  const sqlTotais = `
    SELECT 
      (SELECT COUNT(*) FROM clientes) AS totalClientes,
      (SELECT COUNT(*) FROM remedios) AS totalRemedios
  `;

  const sqlVencidos = `
    SELECT r.id, c.nome AS cliente, r.nome_remedio, r.validade_receita
    FROM remedios r
    JOIN clientes c ON r.cliente_id = c.id
    WHERE DATE(r.validade_receita) < DATE('now')
    ORDER BY r.validade_receita ASC
  `;

  const sqlVencendo = `
    SELECT r.id, c.nome AS cliente, r.nome_remedio, r.validade_receita
    FROM remedios r
    JOIN clientes c ON r.cliente_id = c.id
    WHERE DATE(r.validade_receita) >= DATE('now') AND DATE(r.validade_receita) <= DATE('now', '+7 days')
    ORDER BY r.validade_receita ASC
  `;

  const sqlNaoUrgentes = `
    SELECT r.id, c.nome AS cliente, r.nome_remedio, r.validade_receita,
           ROUND(julianday(r.validade_receita) - julianday('now')) AS dias_restantes
    FROM remedios r
    JOIN clientes c ON r.cliente_id = c.id
    WHERE DATE(r.validade_receita) > DATE('now', '+7 days')
    ORDER BY r.validade_receita ASC
  `;

  db.get(sqlTotais, [], (err, contagem) => {
    if (err) return res.status(500).json({ error: "Erro ao buscar totais." });

    db.all(sqlVencidos, [], (err1, vencidos) => {
      if (err1) return res.status(500).json({ error: "Erro ao buscar vencidos." });

      db.all(sqlVencendo, [], (err2, vencendo) => {
        if (err2) return res.status(500).json({ error: "Erro ao buscar vencendo." });

        db.all(sqlNaoUrgentes, [], (err3, naoUrgentes) => {
          if (err3) return res.status(500).json({ error: "Erro ao buscar não urgentes." });

          res.json({
            totalClientes: contagem.totalClientes,
            totalRemedios: contagem.totalRemedios,
            vencidos: vencidos,
            vencendoNosProximosDias: vencendo,
            vencendoApos7Dias: naoUrgentes
          });
        });
      });
    });
  });
});

// Lista de remédios
app.get("/api/remedios/nomes", (req, res) => {
  db.all("SELECT DISTINCT nome_remedio FROM remedios ORDER BY nome_remedio ASC", [], (err, rows) => {
    if (err) return res.status(500).json({ error: "Erro ao buscar remédios." });
    res.json(rows.map(row => row.nome_remedio));
  });
});

// Cadastro da farmácia
app.post("/api/farmacia", (req, res) => {
  const { nome, cnpj } = req.body;
  const sql = `
    INSERT INTO farmacia (id, nome, cnpj)
    VALUES (1, ?, ?)
    ON CONFLICT(id) DO UPDATE SET nome = excluded.nome, cnpj = excluded.cnpj
  `;
  db.run(sql, [nome, cnpj], function (err) {
    if (err) {
      console.error("Erro ao salvar dados da farmácia:", err.message);
      return res.status(500).json({ message: "Erro ao salvar dados da farmácia." });
    }
    res.json({ message: "Dados da farmácia salvos com sucesso!" });
  });
});

// Registro de envio
function registrarEnvio(cliente_id, tipo) {
  const sql = "INSERT INTO mensagens (cliente_id, tipo, data_envio) VALUES (?, ?, datetime('now'))";
  db.run(sql, [cliente_id, tipo], (err) => {
    if (err) console.error("Erro ao registrar envio:", err.message);
  });
}

// Verificação e envio de lembretes
function verificarEEnviarLembretes() {
  const query = `
    SELECT c.id as cliente_id, c.nome, c.celular, r.nome_remedio, r.validade_receita
    FROM clientes c
    JOIN remedios r ON r.cliente_id = c.id
    WHERE DATE(r.validade_receita) = DATE('now', '+7 day')
       OR DATE(r.validade_receita) = DATE('now', '+3 day')
  `;

  db.all(query, [], async (err, rows) => {
    if (err) return console.error("Erro ao buscar lembretes:", err.message);

    for (const row of rows) {
      const tipo = (row.validade_receita === getDataRelativa(7)) ? "lembrete_7" : "lembrete_3";

      const jaEnviado = await new Promise((resolve) => {
        db.get("SELECT 1 FROM mensagens WHERE cliente_id = ? AND tipo = ?", [row.cliente_id, tipo], (err, r) => {
          resolve(!!r);
        });
      });

      if (!jaEnviado) {
        db.get("SELECT nome FROM farmacia WHERE id = 1", (errF, farmacia) => {
          if (errF || !farmacia) farmacia = { nome: "sua farmácia" };

          const mensagem = tipo === "lembrete_7"
            ? `Olá, ${row.nome}! Sua receita de ${row.nome_remedio} vence em 7 dias. Que tal renovar com antecedência com a ${farmacia.nome}?`
            : `⚠️ Atenção ${row.nome}, sua receita de ${row.nome_remedio} vence em 3 dias! Aproveite e renove com condição especial com a ${farmacia.nome}.`;

          let numero = row.celular.replace(/\D/g, '');
          numero = `+${numero}`;

          enviarMensagemWhatsApp(numero, mensagem)
            .then(() => registrarEnvio(row.cliente_id, tipo))
            .catch(err => console.error("Erro ao enviar lembrete:", err.message));
        });
      }
    }
  });
}


function getDataRelativa(dias) {
  const hoje = new Date();
  hoje.setDate(hoje.getDate() + dias);
  return hoje.toISOString().split("T")[0];
}

// Verificação automática a cada 1 hora
setInterval(verificarEEnviarLembretes, 1000 * 60 * 60);

// Inicia o servidor
app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});

// Excluir receita e enviar mensagem
app.delete("/api/remedios/:id", (req, res) => {
  const remedioId = req.params.id;

  // Busca a receita e o cliente correspondente
  const query = `
    SELECT r.id, r.nome_remedio, c.nome, c.celular
    FROM remedios r
    JOIN clientes c ON r.cliente_id = c.id
    WHERE r.id = ?
  `;

  db.get(query, [remedioId], (err, row) => {
    if (err || !row) return res.status(404).json({ error: "Receita não encontrada." });

    const { nome_remedio, nome, celular } = row;
    let numero = celular.replace(/\D/g, '');
    numero = `+${numero}`;

    db.get("SELECT nome FROM farmacia WHERE id = 1", (errF, farmacia) => {
      if (errF || !farmacia) farmacia = { nome: "sua farmácia" };

      const mensagem = `Olá ${nome}! Sua receita de ${nome_remedio} foi removida do nosso sistema. Caso precise renová-la, estamos à disposição. - ${farmacia.nome}`;

      // Envia mensagem e deleta
      enviarMensagemWhatsApp(numero, mensagem)
        .then(() => {
          db.run("DELETE FROM remedios WHERE id = ?", [remedioId], (errDel) => {
            if (errDel) return res.status(500).json({ error: "Erro ao excluir receita." });
            res.json({ message: "Receita excluída e mensagem enviada ao cliente." });
          });
        })
        .catch((errEnvio) => {
          console.error("Erro ao enviar mensagem:", errEnvio.message);
          res.status(500).json({ error: "Erro ao enviar WhatsApp." });
        });
    });
  });
});

app.post("/api/remedios/:id/enviar-lembrete", (req, res) => {
  const remedioId = req.params.id;

  const query = `
    SELECT r.id, r.nome_remedio, r.validade_receita, c.nome, c.celular
    FROM remedios r
    JOIN clientes c ON r.cliente_id = c.id
    WHERE r.id = ?
  `;

  db.get(query, [remedioId], (err, row) => {
    if (err || !row) return res.status(404).json({ error: "Receita não encontrada." });

    const { nome, nome_remedio, celular } = row;
    let numero = celular.replace(/\D/g, '');
    numero = `+${numero}`;

    db.get("SELECT nome FROM farmacia WHERE id = 1", (errF, farmacia) => {
      if (errF || !farmacia) farmacia = { nome: "sua farmácia" };

      const mensagem = `🔔 Olá ${nome}! Este é um lembrete da ${farmacia.nome}: sua receita de ${nome_remedio} está cadastrada conosco. Lembre-se de verificar sua validade. Se precisar renovar, estamos à disposição!`;

      enviarMensagemWhatsApp(numero, mensagem)
        .then(() => {
          res.json({ message: "Lembrete enviado com sucesso!" });
        })
        .catch((errEnvio) => {
          console.error("Erro ao enviar lembrete:", errEnvio.message);
          res.status(500).json({ error: "Erro ao enviar WhatsApp." });
        });
    });
  });
});
