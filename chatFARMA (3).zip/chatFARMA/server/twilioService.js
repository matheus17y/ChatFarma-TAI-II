require("dotenv").config();
const twilio = require("twilio");

const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const fromNumber = `whatsapp:${process.env.TWILIO_WHATSAPP_NUMBER.replace('whatsapp:', '')}`;

const client = twilio(accountSid, authToken);

async function enviarMensagemWhatsApp(numeroBruto, mensagem) {
  let numeroLimpo = numeroBruto.replace(/\D/g, '');

  if (!numeroLimpo.startsWith('55')) {
    numeroLimpo = '55' + numeroLimpo;
  }

  const tem9 = numeroLimpo.slice(4, 5) === '9';

  const numeroCom9 = tem9
    ? `+${numeroLimpo}`
    : `+${numeroLimpo.slice(0, 4)}9${numeroLimpo.slice(4)}`;

  const numeroSem9 = tem9
    ? `+${numeroLimpo.slice(0, 4)}${numeroLimpo.slice(5)}`
    : `+${numeroLimpo}`;

  // 1. Envio com 9
  console.log(`🔵 Tentando COM 9: ${numeroCom9}`);
  await client.messages
    .create({
      from: fromNumber,
      to: `whatsapp:${numeroCom9}`,
      body: mensagem,
    })
    .then(() => console.log("✅ Enviado com 9"))
    .catch((err) => {
      console.warn(`❌ Erro com 9: ${numeroCom9}`);
      console.log("🪵 Detalhes do erro (com 9):", JSON.stringify(err, null, 2));
    });

  // 2. Envio sem 9
  console.log(`🟡 Tentando SEM 9: ${numeroSem9}`);
  await client.messages
    .create({
      from: fromNumber,
      to: `whatsapp:${numeroSem9}`,
      body: mensagem,
    })
    .then(() => console.log("✅ Enviado sem 9"))
    .catch((err) => {
      console.warn(`❌ Erro com sem 9: ${numeroSem9}`);
      console.log("🪵 Detalhes do erro (sem 9):", JSON.stringify(err, null, 2));
    });
}

module.exports = {
  enviarMensagemWhatsApp,
};
