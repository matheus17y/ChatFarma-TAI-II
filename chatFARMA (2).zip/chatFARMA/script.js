// script.js

document.getElementById("form-cadastro").addEventListener("submit", function (event) {
  event.preventDefault(); // Previne o comportamento padrão do formulário de recarregar a página

  const formData = new FormData(this); // Coleta os dados do formulário

  const data = {};
  formData.forEach((value, key) => {
    data[key] = value;
  });

  fetch("http://localhost:3000/api/clientes", {
    method: "POST",
    headers: {
      "Content-Type": "application/json", // A requisição precisa informar que o corpo é JSON
    },
    body: JSON.stringify(data), // Envia os dados do formulário como JSON
  })
    .then(response => response.json())
    .then(data => {
      if (data.message) {
        alert(data.message); // Exibe a mensagem de sucesso
      } else {
        alert("Erro ao cadastrar cliente.");
      }
    })
    .catch(error => {
      console.error("Erro ao enviar os dados:", error);
      alert("Erro ao enviar os dados.");
    });
});
