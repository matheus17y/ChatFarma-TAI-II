
document.getElementById("cpf").addEventListener("input", function () {
  let cpf = this.value.replace(/\D/g, "");

  if (cpf.length > 11) cpf = cpf.slice(0, 11); // Limita a 11 dígitos

  // Formata automaticamente o CPF
  if (cpf.length > 9) {
    this.value = cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4");
  } else if (cpf.length > 6) {
    this.value = cpf.replace(/(\d{3})(\d{3})(\d+)/, "$1.$2.$3");
  } else if (cpf.length > 3) {
    this.value = cpf.replace(/(\d{3})(\d+)/, "$1.$2");
  } else {
    this.value = cpf;
  }
});

document.getElementById("cpf").addEventListener("blur", async function () {
  const cpfNumeros = this.value.replace(/\D/g, "");

  if (cpfNumeros.length === 11) {
    try {
      const response = await fetch(`/api/clientes?cpf=${cpfNumeros}`);
      const cliente = await response.json();

      if (cliente && cliente.nome) {
        document.getElementById("nome_cliente").value = cliente.nome;
        this.dataset.clienteId = cliente.id;
      } else {
        document.getElementById("nome_cliente").value = "";
        delete this.dataset.clienteId;
        alert("Cliente não encontrado.");
      }
    } catch (err) {
      console.error("Erro ao buscar cliente:", err.message);
      alert("Erro ao buscar cliente.");
    }
  }
});

document.getElementById("remedio-form").addEventListener("submit", async function (e) {
  e.preventDefault();

  const cpfInput = document.getElementById("cpf");
  const clienteId = cpfInput.dataset.clienteId;
  const nomeRemedio = document.getElementById("nome_remedio").value.trim();
  const validade = document.getElementById("validade_receita").value;

  if (!clienteId || !nomeRemedio || !validade) {
    alert("Por favor, preencha todos os campos.");
    return;
  }

  const dados = {
    cliente_id: clienteId,
    nome_remedio: nomeRemedio,
    validade_receita: validade
  };

  try {
    const response = await fetch("/api/remedios", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(dados),
    });

    const result = await response.json();
    if (response.ok) {
      alert("Remédio cadastrado com sucesso!");
      this.reset();
      document.getElementById("nome_cliente").value = "";
    } else {
      alert(result.error || "Erro ao cadastrar remédio.");
    }
  } catch (err) {
    console.error("Erro ao enviar dados:", err.message);
    alert("Erro ao cadastrar remédio.");
  }
});
