document.getElementById("form-cadastro").addEventListener("submit", async function (event) {
  event.preventDefault(); // Evita o recarregamento da página

  // Coleta os dados do formulário
  const formData = new FormData(this);
  const dados = Object.fromEntries(formData.entries());

  try {
    const response = await fetch("/api/clientes", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(dados)
    });

    const result = await response.json();

    if (response.ok) {
      Swal.fire({
        icon: 'success',
        title: 'Sucesso!',
        text: result.message,
        confirmButtonColor: '#00BFA5'
      });
      this.reset(); // Limpa o formulário
    } else if (response.status === 409) {
      // Cliente já existe: perguntar se deseja atualizar
      const confirmacao = await Swal.fire({
        icon: 'warning',
        title: 'Cliente já cadastrado!',
        text: 'Deseja atualizar apenas o Telefone e Email?',
        showCancelButton: true,
        confirmButtonText: 'Sim, atualizar',
        cancelButtonText: 'Não',
        confirmButtonColor: '#00BFA5',
        cancelButtonColor: '#d33'
      });

      if (confirmacao.isConfirmed) {
        // Se confirmou, envia atualização
        dados.atualizar = true; // Adiciona o campo 'atualizar'

        const updateResponse = await fetch("/api/clientes", {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify(dados)
        });

        const updateResult = await updateResponse.json();

        if (updateResponse.ok) {
          Swal.fire({
            icon: 'success',
            title: 'Atualizado!',
            text: updateResult.message,
            confirmButtonColor: '#00BFA5'
          });
          this.reset();
        } else {
          Swal.fire({
            icon: 'error',
            title: 'Erro!',
            text: updateResult.error || 'Erro ao atualizar cliente.',
            confirmButtonColor: '#d33'
          });
        }
      }
      // Se cancelar, não faz nada
    } else {
      Swal.fire({
        icon: 'error',
        title: 'Erro!',
        text: result.error || 'Erro desconhecido.',
        confirmButtonColor: '#d33'
      });
    }

  } catch (error) {
    Swal.fire({
      icon: 'error',
      title: 'Erro na requisição!',
      text: error.message,
      confirmButtonColor: '#d33'
    });
  }
});
