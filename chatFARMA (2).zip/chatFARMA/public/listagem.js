// listagem.js

// Busca clientes do servidor
fetch("http://localhost:3000/api/clientes")
  .then(response => response.json())
  .then(clientes => {
    const tabela = document.getElementById("tabela-clientes");

    clientes.forEach(cliente => {
      const linha = document.createElement("tr");

      linha.innerHTML = `
        <td>${cliente.id}</td>
        <td>${cliente.nome}</td>
        <td>${cliente.data_nasc}</td>
        <td>${cliente.sexo}</td>
        <td>${cliente.telefone}</td>
        <td>${cliente.celular}</td>
        <td>${cliente.rg}</td>
        <td>${cliente.cpf}</td>
        <td>${cliente.endereco}</td>
        <td>${cliente.email}</td>
      `;

      tabela.appendChild(linha);
    });
  })
  .catch(error => {
    console.error("Erro ao buscar clientes:", error);
    alert("Erro ao carregar clientes.");
  });
