async function carregarDashboard() {
  try {
    const response = await fetch("/api/dashboard");
    const dados = await response.json();

    if (response.ok) {
      document.getElementById("total-clientes").innerText = dados.totalClientes;
      document.getElementById("total-remedios").innerText = dados.totalRemedios;

      const lista = document.getElementById("lista-vencendo");
      lista.innerHTML = "";

      if (dados.remediosVencendo.length > 0) {
        dados.remediosVencendo.forEach(item => {
          const linha = document.createElement("tr");
          linha.innerHTML = `
            <td>${item.nome}</td>
            <td>${item.nome_remedio}</td>
            <td>${item.validade_receita}</td>
          `;
          lista.appendChild(linha);
        });
      } else {
        const linha = document.createElement("tr");
        linha.innerHTML = `<td colspan="3">Nenhum remédio vencendo nos próximos 7 dias.</td>`;
        lista.appendChild(linha);
      }

    } else {
      Swal.fire({
        icon: 'error',
        title: 'Erro!',
        text: dados.error || 'Erro ao carregar dashboard.',
        confirmButtonColor: '#d33'
      });
    }

  } catch (error) {
    Swal.fire({
      icon: 'error',
      title: 'Erro na requisição!',
      text: error.message,
      confirmButtonColor: '#d33'
    });
  }
}

// Carregar quando abrir a página
carregarDashboard();
