const connection = require('./database');

// Realize uma consulta simples para testar a conexão
connection.query('SELECT 1 + 1 AS result', (err, results) => {
  if (err) {
    console.error('Erro na consulta: ', err);
  } else {
    console.log('Consulta bem-sucedida: ', results);
  }
  connection.end(); // Fechar a conexão após a consulta
});
