const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const path = require("path");
const db = require("./database");

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static("public"));

// Serve o index.html
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "../public/index.html"));
});

// Rota de login
app.post("/api/login", (req, res) => {
  const { usuario, senha } = req.body;

  const query = "SELECT * FROM usuarios WHERE usuario = ? AND senha = ?";
  db.get(query, [usuario, senha], (err, row) => {
    if (err) {
      res.status(500).json({ error: "Erro ao verificar login." });
    } else if (row) {
      res.status(200).json({ message: "Login bem-sucedido!" });
    } else {
      res.status(401).json({ error: "Usuário ou senha incorretos." });
    }
  });
});



// Cadastro de cliente com verificação de CPF
app.post("/api/clientes", (req, res) => {
  const { nome, telefone, cpf, data_nasc, email, atualizar } = req.body;

  const buscarCliente = "SELECT * FROM clientes WHERE cpf = ?";
  db.get(buscarCliente, [cpf], (err, row) => {
    if (err) {
      console.error("Erro ao buscar cliente:", err.message);
      res.status(500).json({ error: "Erro ao buscar cliente." });
    } else if (row) {
      if (atualizar) {
        // Atualizar apenas telefone e email
        const atualizarCliente = `
          UPDATE clientes
          SET telefone = ?, email = ?
          WHERE cpf = ?
        `;
        db.run(atualizarCliente, [telefone, email, cpf], function (err) {
          if (err) {
            console.error("Erro ao atualizar cliente:", err.message);
            res.status(500).json({ error: "Erro ao atualizar cliente." });
          } else {
            res.status(200).json({ message: "Telefone e Email atualizados com sucesso!" });
          }
        });
      } else {
        res.status(409).json({ error: "Cliente já cadastrado." });
      }
    } else {
      // Inserir novo cliente
      const inserirCliente = `
        INSERT INTO clientes (nome, telefone, cpf, data_nasc, email)
        VALUES (?, ?, ?, ?, ?)
      `;
      db.run(inserirCliente, [nome, telefone, cpf, data_nasc, email], function (err) {
        if (err) {
          console.error("Erro ao cadastrar cliente:", err.message);
          res.status(500).json({ error: "Erro ao cadastrar cliente." });
        } else {
          res.status(201).json({ message: "Cliente cadastrado com sucesso!" });
        }
      });
    }
  });
});

// Buscar cliente por CPF ou listar todos
app.get("/api/clientes", (req, res) => {
  const { cpf } = req.query;

  if (!cpf) {
    // Lista todos os clientes se nenhum CPF for fornecido
    const query = "SELECT * FROM clientes";
    db.all(query, [], (err, rows) => {
      if (err) {
        console.error("Erro ao buscar clientes:", err.message);
        res.status(500).json({ error: "Erro ao buscar clientes." });
      } else {
        res.json(rows);
      }
    });
  } else {
    // Busca cliente por CPF
    const query = "SELECT * FROM clientes WHERE cpf = ?";
    db.get(query, [cpf], (err, row) => {
      if (err) {
        console.error("Erro ao buscar cliente por CPF:", err.message);
        res.status(500).json({ error: "Erro ao buscar cliente." });
      } else if (row) {
        res.json(row);
      } else {
        res.status(404).json({ error: "Cliente não encontrado." });
      }
    });
  }
});



// Cadastro de remédio vinculado a um cliente (com dosagem)
app.post("/api/remedios", (req, res) => {
  const { cliente_id, nome_remedio, validade_receita, dosagem } = req.body;

  // Verificação de campos obrigatórios
  if (!cliente_id || !nome_remedio || !validade_receita || !dosagem) {
    return res.status(400).json({ error: "Todos os campos são obrigatórios." });
  }

  // Comando SQL para inserção
  const inserirRemedio = `
    INSERT INTO remedios (cliente_id, nome_remedio, validade_receita, dosagem)
    VALUES (?, ?, ?, ?)
  `;

  // Executando a inserção no banco
  db.run(inserirRemedio, [cliente_id, nome_remedio, validade_receita, dosagem], function (err) {
    if (err) {
      console.error("Erro ao cadastrar remédio:", err.message);
      res.status(500).json({ error: "Erro ao cadastrar remédio." });
    } else {
      res.status(201).json({ message: "Remédio cadastrado com sucesso!" });
    }
  });
});


// Rota do Dashboard para retornar contagem e lista de remédios prestes a vencer
app.get("/api/dashboard", (req, res) => {
  const sqlContagem = `
    SELECT 
      (SELECT COUNT(*) FROM clientes) AS totalClientes,
      (SELECT COUNT(*) FROM remedios) AS totalRemedios
  `;

  const sqlRemediosVencendo = `
    SELECT c.nome AS cliente, r.nome_remedio, r.validade_receita
    FROM remedios r
    JOIN clientes c ON r.cliente_id = c.id
    WHERE DATE(r.validade_receita) <= DATE('now', '+7 days')
    ORDER BY r.validade_receita ASC
  `;

  db.get(sqlContagem, [], (err, contagem) => {
    if (err) {
      console.error("Erro ao buscar totais:", err.message);
      return res.status(500).json({ error: "Erro ao buscar totais." });
    }

    db.all(sqlRemediosVencendo, [], (err2, lista) => {
      if (err2) {
        console.error("Erro ao buscar remédios:", err2.message);
        return res.status(500).json({ error: "Erro ao buscar remédios." });
      }

      res.json({
        totalClientes: contagem.totalClientes,
        totalRemedios: contagem.totalRemedios,
        vencendoNosProximosDias: lista
      });
    });
  });
});





app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
