const sqlite3 = require("sqlite3").verbose();
const path = require("path");

const dbPath = path.resolve(__dirname, "clientes.db");
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error("Erro ao conectar ao banco de dados:", err.message);
  } else {
    console.log("Conectado ao banco de dados SQLite.");
  }
});

// Criação das tabelas
db.serialize(() => {
  // Tabela de Usuários (login)
  db.run(`
    CREATE TABLE IF NOT EXISTS usuarios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario TEXT UNIQUE,
      senha TEXT
    )
  `);

  // Inserir usuário padrão, se não existir
  db.get(`SELECT * FROM usuarios WHERE usuario = ?`, ['LEONARDO_MELO'], (err, row) => {
    if (err) {
      console.error("Erro ao verificar usuário padrão:", err.message);
    } else if (!row) {
      db.run(`INSERT INTO usuarios (usuario, senha) VALUES (?, ?)`, ['LEONARDO_MELO', 'PUC@2025']);
      console.log("Usuário padrão criado: LEONARDO_MELO / PUC@2025");
    }
  });

  // Tabela de Clientes
  db.run(`
    CREATE TABLE IF NOT EXISTS clientes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL,
      telefone TEXT NOT NULL,
      cpf TEXT NOT NULL UNIQUE,
      data_nasc TEXT NOT NULL,
      email TEXT
    )
  `);

  // Tabela de Remédios
  db.run(`
    CREATE TABLE IF NOT EXISTS remedios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      cliente_id INTEGER,
      nome_remedio TEXT,
      validade_receita TEXT,
      FOREIGN KEY(cliente_id) REFERENCES clientes(id)
    )
  `);

  // Tabela de Histórico de Compras
  db.run(`
  CREATE TABLE IF NOT EXISTS remedios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  cliente_id INTEGER,
  nome_remedio TEXT,
  validade_receita TEXT,
  dosagem TEXT,
  FOREIGN KEY(cliente_id) REFERENCES clientes(id)
)
  `);
});

module.exports = db;
