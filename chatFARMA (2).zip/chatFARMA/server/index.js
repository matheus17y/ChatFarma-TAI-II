const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const path = require("path");
const db = require("./database");

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static("public")); // Para servir arquivos estáticos como CSS, JS

// Serve a página principal
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "../public/index.html"));
});

// Rota para salvar cliente
app.post("/api/clientes", (req, res) => {
  console.log("Requisição recebida com body:", req.body);
  const {
    nome,
    data_nasc,
    sexo,
    telefone,
    celular,
    rg,
    cpf,
    endereco,
    email,
  } = req.body;

  const query = `
    INSERT INTO clientes (nome, data_nasc, sexo, telefone, celular, rg, cpf, endereco, email)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;

  db.run(
    query,
    [nome, data_nasc, sexo, telefone, celular, rg, cpf, endereco, email],
    function (err) {
      if (err) {
        console.error("Erro ao inserir cliente:", err.message);
        res.status(500).json({ error: "Erro ao salvar cliente" });
      } else {
        res.status(200).json({ message: "Cliente salvo com sucesso!" });
      }
    }
  );
});

// Rota para listar todos os clientes
app.get("/api/clientes", (req, res) => {
  const query = "SELECT * FROM clientes";

  db.all(query, [], (err, rows) => {
    if (err) {
      console.error("Erro ao buscar clientes:", err.message);
      res.status(500).json({ error: "Erro ao buscar clientes" });
    } else {
      res.json(rows);
    }
  });
});

app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});

// Cadastro de Remédios
app.post("/api/remedios", (req, res) => {
  const { cpf, nome_remedio, validade_receita } = req.body;

  // Primeiro busca o cliente pelo CPF
  const buscarCliente = "SELECT id FROM clientes WHERE cpf = ?";
  db.get(buscarCliente, [cpf], (err, cliente) => {
    if (err) {
      console.error("Erro ao buscar cliente:", err.message);
      res.status(500).json({ error: "Erro ao buscar cliente." });
    } else if (!cliente) {
      res.status(404).json({ error: "Cliente não encontrado pelo CPF." });
    } else {
      // Inserir remédio
      const inserirRemedio = `
        INSERT INTO remedios (cliente_id, nome_remedio, validade_receita)
        VALUES (?, ?, ?)
      `;
      db.run(inserirRemedio, [cliente.id, nome_remedio, validade_receita], function (err) {
        if (err) {
          console.error("Erro ao cadastrar remédio:", err.message);
          res.status(500).json({ error: "Erro ao cadastrar remédio." });
        } else {
          res.status(201).json({ message: "Remédio cadastrado com sucesso!" });
        }
      });
    }
  });
});
// Rota de login
app.post("/api/login", (req, res) => {
  const { usuario, senha } = req.body;

  const query = "SELECT * FROM usuarios WHERE usuario = ? AND senha = ?";
  db.get(query, [usuario, senha], (err, row) => {
    if (err) {
      res.status(500).json({ error: "Erro ao verificar login." });
    } else if (row) {
      res.status(200).json({ message: "Login bem-sucedido!" });
    } else {
      res.status(401).json({ error: "Usuário ou senha incorretos." });
    }
  });
});
